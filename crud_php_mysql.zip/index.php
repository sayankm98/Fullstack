<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['task'])) {
        $stmt = $conn->prepare("INSERT INTO tasks (task) VALUES (?)");
        $stmt->bind_param("s", $_POST['task']);
        $stmt->execute();
    } elseif (isset($_POST['delete'])) {
        $stmt = $conn->prepare("DELETE FROM tasks WHERE id = ?");
        $stmt->bind_param("i", $_POST['delete']);
        $stmt->execute();
    } elseif (isset($_POST['update'])) {
        $stmt = $conn->prepare("UPDATE tasks SET task = ? WHERE id = ?");
        $stmt->bind_param("si", $_POST['new_task'], $_POST['update']);
        $stmt->execute();
    }
}

$result = $conn->query("SELECT * FROM tasks");
?>
<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>PHP MySQL CRUD</title>
    <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css'>
</head>
<body class='container mt-5'>
    <div class='card p-4 shadow-lg'>
        <h2 class='text-center text-primary'>Task Manager</h2>
        <form method="post" class='input-group mb-3'>
            <input type="text" name="task" class='form-control' placeholder="New Task" required>
            <button type="submit" class='btn btn-success'>Add Task</button>
        </form>
        <table class='table table-bordered'>
            <thead>
                <tr><th>Task</th><th>Actions</th></tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo $row['task']; ?></td>
                        <td>
                            <form method="post" class='d-inline'>
                                <input type="hidden" name="delete" value="<?php echo $row['id']; ?>">
                                <button type="submit" class='btn btn-danger btn-sm'>Delete</button>
                            </form>
                            <form method="post" class='d-inline'>
                                <input type="hidden" name="update" value="<?php echo $row['id']; ?>">
                                <input type="text" name="new_task" class='form-control d-inline w-50' required>
                                <button type="submit" class='btn btn-warning btn-sm'>Update</button>
                            </form>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</body>
</html>