<?php
session_start();
include('config/db.php');

if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit();
}

$username = $_SESSION['user'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $task = $_POST['task'];
    $query = "INSERT INTO tasks (username, task) VALUES ('$username', '$task')";
    $conn->query($query);
}

$query = "SELECT * FROM tasks WHERE username='$username'";
$result = $conn->query($query);
?>
<!DOCTYPE html>
<html>
<head><title>Tasks</title></head>
<body>
    <h2>Task List</h2>
    <form method="post">
        <input type="text" name="task" required>
        <input type="submit" value="Add Task">
    </form>
    <ul>
        <?php while ($row = $result->fetch_assoc()) { echo "<li>{$row['task']}</li>"; } ?>
    </ul>
    <a href='index.php'>Back</a>
</body>
</html>